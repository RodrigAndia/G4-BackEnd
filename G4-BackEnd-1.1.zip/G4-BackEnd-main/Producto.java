package com.everis.formativa1;

public class Producto {
	
	private String codigo;
	private double precioBase;
	private String nombre;
	private boolean generico;
	private int cantVitaminas;
	private String infoVitaminas;
	private String contraindicaciones;
	
	

}
